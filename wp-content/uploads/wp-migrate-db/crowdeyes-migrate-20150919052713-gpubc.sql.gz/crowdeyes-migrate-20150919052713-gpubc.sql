# WordPress MySQL database migration
#
# Generated: Saturday 19. September 2015 05:27 UTC
# Hostname: localhost
# Database: `crowdeyes`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cr_commentmeta`
#

DROP TABLE IF EXISTS `wp_cr_commentmeta`;


#
# Table structure of table `wp_cr_commentmeta`
#

CREATE TABLE `wp_cr_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_cr_commentmeta`
#

#
# End of data contents of table `wp_cr_commentmeta`
# --------------------------------------------------------

